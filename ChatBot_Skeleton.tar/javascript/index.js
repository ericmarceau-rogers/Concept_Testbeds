document.addEventListener("DOMContentLoaded", () => {
  const inputField = document.getElementById("input_ctrl");
  inputField.addEventListener("keydown", (e) => {
    if (e.code === "Enter") {
      let input = inputField.value;
      inputField.value = "";
      output(input);
    }
  });
});

function output(input) {
  //
  //	SEGMENT -- EVAL/CLEANUP of input
  //
  // Regex remove non word/space chars
  // Trim trailing whitespce
  // Remove digits - not sure if this is best
  // But solves problem of entering something like 'hi1'

  let text = input.toLowerCase().replace(/[^\w\s]/gi, "").replace(/[\d]/gi, "").trim();
  text = text
  /*
    .replace(/ a /g, " ")   // 'tell me a story' -> 'tell me story'
    .replace(/i feel /g, "")
    .replace(/whats/g, "what is")
    .replace(/please /g, "")
    .replace(/ please/g, "")
    .replace(/r u/g, "are you");
  */

  //
  //	SEGMENT -- SEARCH for match on input sub-string in order to generate pertinent response text
  //
  let product;

/*
  if (compare(prompts, replies, text)) { 
    // Search for exact match in `prompts`
    product = compare(prompts, replies, text);
  } else if (text.match(/thank/gi)) {
    product = "You're welcome!"
  } else if (text.match(/(corona|covid|virus)/gi)) {
    // If no match, check if message contains `coronavirus`
    product = coronavirus[Math.floor(Math.random() * coronavirus.length)];
  } else {
    // If all else fails: random alternative
    product = alternative[Math.floor(Math.random() * alternative.length)];
  }
*/

  //
  //	SEGMENT -- FORCED random response to detected input
  //
  product = alternative[Math.floor(Math.random() * alternative.length)];

  //
  //	SEGMENT -- DISPLAY desired text
  //
  // Update DOM
  addChat_ctrl(input);
  addChat_stat(product);
}

function compare(promptsArray, repliesArray, string) {
  let reply;
  let replyFound = false;
  for (let x = 0; x < promptsArray.length; x++) {
    for (let y = 0; y < promptsArray[x].length; y++) {
      if (promptsArray[x][y] === string) {
        let replies = repliesArray[x];
        reply = replies[Math.floor(Math.random() * replies.length)];
        replyFound = true;
        // Stop inner loop when input value matches prompts
        break;
      }
    }
    if (replyFound) {
      // Stop outer loop when reply is found instead of interating through the entire array
      break;
    }
  }
  return reply;
}

//
//	SEGMENT -- Low-level handling of text display in CTRL element
//
function addChat_ctrl(input) {
  const messagesContainer = document.getElementById("messages_ctrl");
  let userDiv = document.createElement("div");
  userDiv.id = "user";
  userDiv.className = "user response_ctrl";
  /* */
  let userImg = document.createElement("img");
  userImg.src = "images/user.png";
  userImg.className = "avatar";
  userDiv.appendChild(userImg);
  /* */
  let userText = document.createElement("span");
  // Use USER-supplied input
  userText.innerText = `${input}`;
  userDiv.appendChild(userText) ;
  /* */
  messagesContainer.appendChild(userDiv);
  // Keep messages at most recent
  messagesContainer.scrollTop = messagesContainer.scrollHeight - messagesContainer.clientHeight;
}

//
//	SEGMENT -- Low-level handling of text display in STAT element
//
function addChat_stat(product) {
  const messagesContainer = document.getElementById("messages_stat");
  let botDiv = document.createElement("div");
  botDiv.id = "bot";
  botDiv.className = "bot response_stat";
  /* */
  let botImg = document.createElement("img");
  botImg.src = "images/bot-mini.png";
  botImg.className = "avatar";
  botDiv.appendChild(botImg);
  /* */
  let botText = document.createElement("span");
  /*
  // Assign transient placeholder text for faking interraction with live person
  botText.innerText = "Typing...";
  */
  //	IMMEDIATE display of identified response
  botText.innerText = `${product}`;
  botDiv.appendChild(botText);
  /* */
  messagesContainer.appendChild(botDiv);
  // Keep messages at most recent
  messagesContainer.scrollTop = messagesContainer.scrollHeight - messagesContainer.clientHeight;

  /*
  //
  //	DELAYED Display (2 sec) to fake response from live person
  //
	setTimeout(() => {
	    botText.innerText = `${product}`;
	    // textToSpeech(product)
	  }, 2000
	)
  */

}
