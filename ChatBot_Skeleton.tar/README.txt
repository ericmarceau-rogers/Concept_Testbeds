###
###	Eric Marceau, Ottawa, Canada
###	Feb 22, 2025
###

This chatbot coding is modified from the original at

	https://github.com/sylviapap/chatbot

The evolution of this code was halted at the point where there would be
major divergence from the original concept of a Chatbot, and the concept
for which this project was started, which was to correctly identify the
mechanisms for adding user input (logging of decisions/actions) at the
bottom of a scrolling element in a multi-pane HTML+CSS+Javascript 
interractive game.

The Chatbot in this form still maintains the integrity of separation of
User input and responding server feedback/response.

Responses are currently simulated, using very basic randomized answers
that try to be relevant (via simple word lookup) to identify thei
corresponding grouping of those releant responses.

###	EOT
