window.addEventListener("load", function(){
	setTimeout(
		function open(event){
			document.querySelector(".popup").style.display = "block" ;
		},
		// this value controls the delay before popup is displayed 
		0
	) ;
} ) ;

setTimeout(
	function open(event){
		var inputBox = document.getElementById("popup_input_text") ;
		inputBox.focus() ;
		inputBox.scrollIntoView() ;
/*
		var inputBox = document.querySelector("#popup_input_text") ;
		inputBox.focus() ;
		inputBox.scrollIntoView() ;
*/
	},
	// this value controls the delay before popup is displayed 
	150
) ;

document.querySelector("#button_close").addEventListener("click", function(){
    document.querySelector(".popup").style.display = "none" ;
} ) ;

const inputBox = document.getElementById("popup_input_text") ;
inputBox.addEventListener("keyup", function(event) {
    if (event.key === "Enter") {
        // Do work
    	document.querySelector(".popup").style.display = "none" ;
	//
	// Perform above, then any other coded action using the supplied input
	//
    }
})

