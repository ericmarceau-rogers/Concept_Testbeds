// -----------------------------------------------------------------------------------
//
//	Adapted from solution offered by Google search bot
//	SOURCE:	Google Search
//
//	ALTERNATE REF:
//	https://dev.to/nordicbeaver/a-real-life-example-of-making-a-custom-promise-in-javascript-typesctipt-5d1n
//
// -----------------------------------------------------------------------------------
function loadHTML(url) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open('GET', url);
		// -------------------------------------------------------------------
		xhr.onload = () => {
			if (xhr.status >= 200 && xhr.status < 300) {
				resolve(xhr.response);
			} else {
				reject(`Error loading HTML: Status ${xhr.status}`);
			}
		};
		// -------------------------------------------------------------------
		xhr.onerror = () => {
			reject("Network error");
		};
		// -------------------------------------------------------------------
		xhr.send();
	});
}

// -----------------------------------------------------------------------------------
//
//	USAGE:	Typical coding for usage
//
// -----------------------------------------------------------------------------------
//loadHTML('my-content.html')
//	.then(html => {
//		document.getElementById('content-container').innerHTML = html;
//		console.log('HTML loaded successfully!');
//	})
//	.catch(error => {
//		console.error(error);
//	}) ;
// -----------------------------------------------------------------------------------
