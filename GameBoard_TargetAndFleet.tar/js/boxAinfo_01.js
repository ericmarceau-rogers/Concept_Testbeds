// -----------------------------------------------------------------------------------
//
//	FAILED:  Code to load HTML page into a ests to display ship status details
//
// -----------------------------------------------------------------------------------
let file = 'html/shipInfo.html' ;

async function fetchPageJSON(page) {
	const response = await fetch(page) ;
	const details = await response.blob() ;
	return details ;

fetchPageJSON(file).then(details => {
	document.getElementById('boxAinfo').innerHTML = details ; // fetched details
});


// -----------------------------------------------------------------------------------
//
//	FAILED:	 Alternate attempt at loading a page 
//
// -----------------------------------------------------------------------------------
//	try {
//		await fetch('html/bannerInfo.html') ;
//	} catch(err) {
//		alert(err) ; // Failed to fetch
//	}


