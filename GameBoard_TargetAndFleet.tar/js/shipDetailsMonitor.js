// -----------------------------------------------------------------------------------
//
//	Monitor mouse actions for requests to display ship status details
//
// -----------------------------------------------------------------------------------
//
//	METHOD 1 - reporting element on click event
//	REF:  https://www.reddit.com/r/learnjavascript/comments/1d9hp09/know_which_div_was_clicked/
//const parentContainer = document.querySelector('#boxCsubD') ;
//parentContainer.addEventListener('click', (event) => {
//	//console.log(event.target.id)
//	output( msgDbg.concat("Ship element id => " , event.target.id ) )
//) ;
//
//
//	METHOD 2 - reporting element on mousedown event
//	REF:  https://www.reddit.com/r/learnjavascript/comments/1d9hp09/comment/l7ds030/
//const divs = document.querySelectorAll('.your-class-name');
var currentShip = 'ship0' ;

const divs = document.querySelectorAll('shipid');
divs.forEach((div) => {
	// FUTURES: slide-in/-out from side drawer
	//div.addEventListener('mousedown', (event) => {
	div.addEventListener('mouseover', (event) => {
		//console.dir(event);
		currentShip = event.target.id ;
		output( msgDbg.concat("Ship element id => " , currentShip ) ) ;
		//
		// ---------------------------------------------------------------------------
		//
		//	FAILED:	This approach fails to load html contents of identified file
		//
		// ---------------------------------------------------------------------------
		//fetch(file)
		//	.then(response => response.json())
		//	.then(data => {
		//		//document.getElementById('boxDinfo').innerHTML = `<p>${data.content}</p>`;
		//		document.getElementById('boxDinfo').innerHTML = `${data.content}` ;
		//	})
		//	.catch(error => console.error('Error fetching data:', error));
		// ---------------------------------------------------------------------------
		//
		let file = 'html/bannerInfo.html' ;
		var shipInfoElem = document.getElementById('boxDinfo')
		var shipStatusDetails = document.getElementById('shipStatusDetails')
//		loadHTML(file)
//			.then(html => {
//				//shipInfoElem.innerHTML = `${html.content}` ;
//				shipInfoElem.innerHTML = html ;
//				//console.log('HTML loaded successfully!');
//				output( msgDbg.concat("Loaded HTML for " , currentShip , " successfully!" ) ) ;
//			})
//			.catch(error => {
//				console.error(error) ;
//			}) ;
//		//
		divHide('boxDdefault') ;
		divShow('boxDinfo') ;
		//shipInfoElem.innerHTML = msgDbg.concat("Loaded HTML for " , currentShip , " successfully!" ) ;
		// WHY is the following not working ???
		shipStatusDetails.innerHTML = msgDbg.concat("Loaded HTML for " , currentShip , " successfully!" ) ;
	});
	// FUTURES: slide-in/-out from side drawer
	//div.addEventListener('mouseup', (event) => {
	div.addEventListener('mouseout', (event) => {
		//console.dir(event);
		divHide('boxDinfo') ;
		divShow('boxDdefault') ;
		output( msgDbg.concat("Fleet view restored " , "..." ) ) ;
	});
});
