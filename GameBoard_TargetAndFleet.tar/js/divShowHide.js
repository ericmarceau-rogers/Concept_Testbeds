// ----------------------------------------------------------------------------------------
//
//	Functions for manipulating display mode for div elements
//
// ----------------------------------------------------------------------------------------
function divHide(id)	{ document.getElementById(id).style.display = "none" ;  }

function divShow(id)	{ document.getElementById(id).style.display = "block" ; }

function toggleDiv(id) {
	var div = document.getElementById(id) ;
	div.style.display = div.style.display == "none" ? "block" : "none" ;
}

