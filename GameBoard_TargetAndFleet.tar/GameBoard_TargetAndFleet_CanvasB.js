function loadGameSurfaceB()
{
	const divBoxD = document.getElementById("boxD") ;
	const  canvas = document.getElementById("gameSurfaceB") ;

	// Image used for background of Target Field
	var imgTF = new Image();

	// Test for availability of Canvas context to work with
	if (canvas.getContext) {
		// Canvas Supported
	
		var fleetView = canvas.getContext("2d") ;

		// FUTURES:  Use these to verify playing surface is fully visible
		//window.screen.availHeight ;
		//window.screen.availWidth ;
		
		// Make sure the image is loaded first otherwise nothing will draw.
		imgTF.onload = function(){
			const divDWidth  = imgTF.width;
			const divDHeight = imgTF.height;

			divBoxD.style.width  = divDWidth ;
			divBoxD.style.height = divDHeight ;

			fleetView.width  = divDWidth ;
			fleetView.height = divDHeight ; 
	
			// code here to use the dimensions
			fleetView.drawImage( imgTF, 0, 0, fleetView.width, fleetView.height, 0, 0, fleetView.width, fleetView.height ) ;
		}

		// Defining actions for identified surface context
		
		// set the new background image
		imgTF.src = "./images/GameBoard_FleetView__26c26r.png" ;


//  FUTURES
//		// Store the current transformation matrix
//		fleetView.save();
//
//		// Use the identity matrix while clearing the canvas
//		fleetView.setTransform(1, 0, 0, 1, 0, 0);
//		fleetView.clearRect(0, 0, canvas.width, canvas.height);
//
//		// Restore the transform
//		fleetView.restore();
		
	//}else{
		// Actions to take if canvas is NOT supported
	} ;  
} ;


//	REF:  https://stackoverflow.com/questions/10791610/javascript-html5-using-image-to-fill-canvas
