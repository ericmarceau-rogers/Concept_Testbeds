function loadGameSurfaceA()
{
	const divBoxB = document.getElementById("boxB") ;
	const  canvas = document.getElementById("gameSurfaceA") ;

	// Image used for background of Target Field
	var imgTF = new Image();

	// Test for availability of Canvas context to work with
	if (canvas.getContext) {
		// Canvas Supported
	
		var gameBoard = canvas.getContext("2d") ;

		// FUTURES:  Use these to verify playing surface is fully visible
		//window.screen.availHeight ;
		//window.screen.availWidth ;
		
		// Make sure the image is loaded first otherwise nothing will draw.
		imgTF.onload = function(){
			const divBWidth  = imgTF.width;
			const divBHeight = imgTF.height;

			divBoxB.style.width  = divBWidth ;
			divBoxB.style.height = divBHeight ;

			gameBoard.width  = divBWidth ;
			gameBoard.height = divBHeight ; 
	
			// code here to use the dimensions
			gameBoard.drawImage( imgTF, 0, 0, gameBoard.width, gameBoard.height, 0, 0, gameBoard.width, gameBoard.height ) ;
		}

		// Defining actions for identified surface context
		
		// set the new background image
		imgTF.src = "./images/GameBoard_TargetField__26c26r.png" ;


//  FUTURES
//		// Store the current transformation matrix
//		gameBoard.save();
//
//		// Use the identity matrix while clearing the canvas
//		gameBoard.setTransform(1, 0, 0, 1, 0, 0);
//		gameBoard.clearRect(0, 0, canvas.width, canvas.height);
//
//		// Restore the transform
//		gameBoard.restore();
		
	//}else{
		// Actions to take if canvas is NOT supported
	} ;  
} ;


//	REF:  https://stackoverflow.com/questions/10791610/javascript-html5-using-image-to-fill-canvas
