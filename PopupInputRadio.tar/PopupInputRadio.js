window.addEventListener("load", function(){
    setTimeout(
        function open(event){
            document.querySelector(".popup").style.display = "block" ;
        },
	// this value controls the delay before popup is displayed 
        0
    )
} ) ;


document.querySelector("#button_close").addEventListener("click", function(){
    document.querySelector(".popup").style.display = "none" ;
} ) ;


//
//	SEGMENT -- Upon detection of button click, close popup and take action selected
//
document.getElementById('option1').onclick = function () { 
    setTimeout(
        function open(event){
		document.querySelector(".popup").style.display = "none" ;
		//
		// Perform above, then any other coded action using the supplied input
		//
		console.log('You clicked radio button for Option_1'); 
        },
	// this value controls the delay before popup is collapsed 
        300
    )
} ;
document.getElementById('option2').onclick = function () { 
    setTimeout(
        function open(event){
		document.querySelector(".popup").style.display = "none" ;
		//
		// Perform above, then any other coded action using the supplied input
		//
		console.log('You clicked radio button for Option_2'); 
        },
	// this value controls the delay before popup is collapsed 
        300
    )
} ;
document.getElementById('option3').onclick = function () { 
    setTimeout(
        function open(event){
		document.querySelector(".popup").style.display = "none" ;
		//
		// Perform above, then any other coded action using the supplied input
		//
		console.log('You clicked radio button for Option_3'); 
        },
	// this value controls the delay before popup is collapsed 
        300
    )
} ;
