document.addEventListener("DOMContentLoaded", () => {
  const inputField = document.getElementById("input_ctrl") ;
  inputField.addEventListener("keydown", (e) => {
    if (e.code === "Enter") {
      let input = inputField.value ;
      inputField.value = "" ;
      output(input) ;
    }
  } ) ;
} ) ;


function output(input) {
  //
  //	SEGMENT -- EVAL/CLEANUP of input
  //
  // Regex remove non word/space chars
  // Trim trailing whitespce
  // Remove digits

  let text = input.toLowerCase().replace(/[^\w\s]/gi, "").replace(/[\d]/gi, "").trim() ;
  text = text

  //
  //	SEGMENT -- DISPLAY desired text
  //
  // Update DOM

  const lang = navigator.language || navigator.languages[0] ;
  const date = new Date() ;

  const date_locale = date.toLocaleDateString( lang, {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  } ) ;

  const time_locale = date.toLocaleTimeString( lang, {
    hour12: false
  } ) ;

  var now = time_locale ;
  addChat_ctrl( now, input ) ;
}

//
//	SEGMENT -- Low-level handling of text display in CTRL element
//
function addChat_ctrl(now,input) {
  const messagesContainer = document.getElementById("messages_ctrl") ;
  let userDiv = document.createElement("div") ;
  userDiv.id = "user" ;
  userDiv.className = "user response_ctrl" ;
  /* */
  let userTime = document.createElement("span") ;
  var msg = "" ;
  userTime.setAttribute("style", "color: #BFBFBF ; font-weight: bold; " ) ;
  userTime.innerText = msg.concat("[" , now , "] " ) ;
  userDiv.appendChild(userTime) ;
  /* */
  let userText = document.createElement("span") ;
  // Use USER-supplied input
  userText.innerText = input ;
  userDiv.appendChild(userText) ;
  /* */
  messagesContainer.appendChild(userDiv) ;
  // Keep messages at most recent
  messagesContainer.scrollTop = messagesContainer.scrollHeight - messagesContainer.clientHeight ;
}

